namespace SudokuSolver.Domain.ValueObjects
{
    public record Position(int Row, int Col);
}
